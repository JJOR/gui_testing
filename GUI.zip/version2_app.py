from flask import Flask, render_template, request, redirect

app = Flask(__name__)

# Define the routes for each page
@app.route('/')
def page1():
    return render_template('page1.html')

@app.route('/page2', methods=['GET', 'POST'])
def page2():
    if request.method == 'POST':

        coverage_amount = request.form.get('coverage_amount')
        
        beneficiary_name = request.form.get('beneficiary_name')
        
        own_life = request.form.get('own_life')
        
        return render_template('page2.html')
    return redirect('/')

@app.route('/page3', methods=['GET', 'POST'])
def page3():
    if request.method == 'POST':


        tobacco_use = request.form.get('tobacco_use')
        
        life_insurance = request.form.get('life_insurance')
        
        admitted_to = request.form.get('admitted_to')
        
        
        return "Thank you for submitting the form!"
    
    return render_template('page3.html')

if __name__ == '__main__':
    app.run(debug=True)