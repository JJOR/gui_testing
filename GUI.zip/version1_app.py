from flask import Flask, render_template, request, redirect

app = Flask(__name__)

# Define the routes for each page
@app.route('/')
def page1():
    return render_template('page1.html')

@app.route('/page2', methods=['GET', 'POST'])
def page2():
    if request.method == 'POST':
        # Process the form data from page 2
        coverage_amount = request.form.get('coverage_amount')
        own_life = request.form.get('own_life')
        beneficiary_name = request.form.get('beneficiary_name')
        # Perform any desired operations with the form data
        
        return render_template('page2.html')
    
    #return render_template('page2.html')
    return redirect('/')

@app.route('/page3', methods=['GET', 'POST'])
def page3():
    if request.method == 'POST':
        # Process the form data from page 3
        life_insurance = request.form.get('life_insurance')
        admitted_to = request.form.get('admitted_to')
        tobacco_use = request.form.get('tobacco_use')
        # Perform any desired operations with the form data
        
        return "Thank you for submitting the form!"
    
    return render_template('page3.html')

if __name__ == '__main__':
    app.run(debug=True)